package main

import (
	"github.com/defectdojo/godojo/cmd"
)

func main() {
	// start installer
	cmd.Main()

}
